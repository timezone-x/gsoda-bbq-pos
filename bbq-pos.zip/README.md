# gsoda-bbq-pos
An easy to use POS System designed for the GSODA Junior Players to use at Bunnings Sausage Sizzle Fundraisers.
